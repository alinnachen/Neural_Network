def test_setup():
    assert True == True